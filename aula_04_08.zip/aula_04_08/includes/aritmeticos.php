<?php
include __DIR__."/header.php";
?>
<hgroup>
<h1>Operadores Aritméticos</h1>
<h2>Cálculos com PHP</h2>
</hgroup>
<h3>Soma</h3>
<?php echo 5+3;?>
<h3>Subtração</h3>
<?php echo 763-272;?>
<h3>Divisão</h3>
<?php echo 325/6;?>
<h3>Multiplicação</h3>
<?php echo 54*36;?>
<h3>Potenciação</h3>
<?php echo pow(3,5);?>
<?php
include __DIR__."/footer.php";
?>
