<footer>
    <p>Todos os direitos Reservados</p>
    <address>Prof.Ulisses</address>
</footer>
</body>
</html>