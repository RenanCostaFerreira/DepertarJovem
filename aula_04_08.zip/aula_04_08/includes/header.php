<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/aula_04_08/css/config.css">
    <title>Projeto</title>
</head>
<body>
   <header><h1>Meu Projeto</h1></header>