Parte 1 - Básico (1 a 10)



1\. Escreva um programa que peça ao usuário dois números e mostre a soma deles.



**valor=int(input("Digite um numero:"))**



**valor2=int(input("Digite outro numero:"))**



**print("Seu resultado:", valor+valor2)**



2R:



**valor = int(input("digite um numero:"))**



**if valor % 2 == 0:**



    **print("Seu numero é par")**



**else:**



    **print("Seu numero é impar")**



3R:



celsius = int(input("Digite a temperatura:"))



print(f"A temperatura {celsius}ºC em fahrenheit é:", celsius\*1.8+32)



4R:



